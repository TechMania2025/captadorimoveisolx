import { GoogleGenAI } from "@google/genai";
import { ScraperConfig, SellerType, SortType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

/**
 * Constrói a URL de busca da OLX manualmente quando a busca é por bairro ou município.
 * @param config A configuração do scraper.
 * @returns A URL de busca formatada.
 */
export function buildLocationSearchUrl(config: ScraperConfig): string {
    if (!config.state) {
        throw new Error("O estado (UF) é obrigatório para a busca por localização.");
    }

    const baseUrl = `https://www.olx.com.br/estado-${config.state.toLowerCase()}`;
    const params = new URLSearchParams();

    // q (query for location)
    const locations = [...config.neighborhoods, ...config.municipalities];
    if (locations.length > 0) {
        params.set('q', locations.join(' '));
    }

    // Price (ps, pe)
    if (config.minPrice > 0) {
        params.set('ps', config.minPrice.toString());
    }
    if (config.maxPrice > 0) {
        params.set('pe', config.maxPrice.toString());
    }

    // OLX Guarantee (opst)
    if (config.olxGuarantee) {
        params.set('opst', config.olxGuarantee.toString());
    }

    // Seller Type (f)
    if (config.sellerType === SellerType.Particular) {
        params.set('f', 'p');
    } else if (config.sellerType === SellerType.Profissional) {
        params.set('f', 'c');
    }

    // Sort (sf, sp)
    switch (config.sort) {
        case SortType.Recentes:
            params.set('sf', '1');
            break;
        case SortType.MenorPreco:
            params.set('sp', '1');
            break;
        case SortType.MaiorPreco:
            params.set('sp', '5');
            break;
        // case SortType.Relevantes: -> do nothing, this is the default
    }

    // OLX uses %20 for spaces in the 'q' param, while URLSearchParams encodes to '+'.
    // We replace it to match the required format.
    const queryString = params.toString().replace(/\+/g, '%20');
    return queryString ? `${baseUrl}?${queryString}` : baseUrl;
}


export async function generateOlxUrl(config: ScraperConfig): Promise<string> {
    const prompt = `
      Você é um assistente especialista em construir URLs de busca de imóveis para a OLX. Sua única tarefa é construir a URL de busca perfeita com base nos critérios do usuário e no guia definitivo de parâmetros da OLX abaixo.

      Esta tarefa é para buscas **sem bairros ou municípios específicos**. A busca é baseada em cidade/estado e outros filtros detalhados.

      **GUIA DEFINITIVO DE CONSTRUÇÃO DE URL OLX**
      
      1.  **Construa o Caminho (Path):** O caminho base é \`/imoveis/venda/\`. Ele **SEMPRE** inclui o estado e a cidade (ex: \`/imoveis/venda/estado-se/sergipe/aracaju\`).
      2.  **Determine o Segmento Principal:**
          *   **Prioridade 1 (Subtipo Único):** Se **exatamente um** subtipo de imóvel for selecionado, insira o 'Slug de Caminho' desse subtipo antes do estado. Ex: \`/imoveis/venda/casas-de-condominio/estado-se/sergipe/aracaju\`.
          *   **Prioridade 2 (Comodidade Única):** Se nenhum subtipo for selecionado E **exatamente uma** das "Comodidades Caminháveis" for selecionada, insira o 'Slug de Caminho' dessa comodidade. Ex: \`/imoveis/venda/piscina/estado-se/sergipe/aracaju\`.
          *   **Fallback (Padrão):** Se nenhuma das condições acima for atendida, use o slug do tipo de imóvel principal (\`casas\`, \`apartamentos\`) se apenas um for selecionado. Se ambos (ou nenhum) forem, não adicione nada extra ao caminho base.
      3.  **Construa a Query String:** Adicione todos os filtros aplicáveis como parâmetros de query.

      ---
      **DICIONÁRIOS DE CÓDIGOS E SLUGS**

      | Item | Parâmetro / Código / Slug de Caminho |
      |:---|:---|
      | **Tipo Imóvel** | **Parâmetro:** \`ret=1040\` (Casa), \`ret=1020\` (Apto). Repita se ambos selecionados. **Slug de Caminho (Fallback):** \`casas\`, \`apartamentos\`. |
      | **Subtipo Imóvel** | **Slug (Se único):** \`casas-de-condominio\`, \`casas-de-vila\`, \`cobertura\`, \`duplex-ou-triplex\`, \`kitnet\`, \`loft\`, \`flats\`. **Código (Se múltiplos):** Padrão: \`rts=300\`, Casa de condomínio: \`rts=300\`, Casa de vila: \`rts=301\`, Cobertura: \`rts=302\`, Duplex ou triplex: \`rts=303\`, Kitnet: \`rts=304\`, Loft: \`rts=305\`, Flat: \`rts=306\`. |
      | **Comodidades** | **Caminháveis (Se únicas):** Piscina -> \`piscina\`, Academia -> \`academia\`, Mobiliado -> \`mobiliado\`, Churrasqueira -> \`churrasqueira\`, Varanda -> \`varanda\`. **Códigos (Sempre que aplicável):** Academia: \`rfs=100\`, Aquecimento: \`rfs=101\`, Ar Condicionado: \`rfs=102\`, Área de serviço: \`rfs=103\`, Armários na cozinha: \`rfs=104\`, Armários no quarto: \`rfs=105\`, Banheiro no quarto (suíte): \`rfs=106\`, Churrasqueira: \`rfs=107\`, Internet: \`rfs=108\`, Mobiliado: \`rfs=109\`, Piscina: \`rfs=110\`, Porteiro 24h: \`rfs=111\`, Quarto de serviço: \`rfs=112\`, Salão de festas: \`rfs=113\`, TV a cabo: \`rfs=114\`, Varanda: \`rfs=115\`. |
      | **Detalhes Condomínio** | **Códigos:** Academia: \`rcf=200\`, Área murada: \`rcf=201\`, Condomínio fechado: \`rcf=202\`, Elevador: \`rcf=203\`, Permitido animais: \`rcf=204\`, Piscina: \`rcf=205\`, Portão eletrônico: \`rcf=206\`, Portaria: \`rcf=207\`, Salão de festas: \`rcf=208\`, Segurança 24h: \`rcf=209\`. |
      | **Ordenação** | Recentes: \`sf=1\`. Menor Preço: \`sp=1\`. Maior Preço: \`sp=5\`. Relevantes: **NENHUM** parâmetro. |
      | **Vendedor** | Particular: \`f=p\`. Profissional: \`f=c\`. Todos: **NENHUM** parâmetro. |
      | **Outros** | Preço: \`ps\`(min)/\`pe\`(max). Condomínio: \`cos\`(min)/\`coe\`(max). IPTU: \`ips\`(min)/\`ipe\`(max). Área: \`ss\`(min)/\`se\`(max). Quartos: \`ros\`. Banheiros: \`bas\`. Vagas: \`gsp\`. |
      
      ---
      **EXEMPLOS PRÁTICOS PARA SEGUIR:**

      *   **Caso 1 (Comodidade Única):** Apenas Piscina.
          *   **Lógica:** Exatamente uma comodidade caminhável -> Usar slug \`piscina\` no caminho.
          *   **URL:** \`https://www.olx.com.br/imoveis/venda/piscina/estado-se/sergipe/aracaju\`
      *   **Caso 2 (Múltiplas Comodidades):** Piscina, Academia.
          *   **Lógica:** Mais de uma comodidade -> Usar códigos \`rfs\` como parâmetros. Caminho padrão.
          *   **URL:** \`https://www.olx.com.br/imoveis/venda/estado-se/sergipe/aracaju?rfs=110&rfs=100\`
      *   **Caso 3 (Subtipo Único):** Apenas Cobertura.
          *   **Lógica:** Exatamente um subtipo -> Usar slug \`cobertura\` no caminho.
          *   **URL:** \`https://www.olx.com.br/imoveis/venda/cobertura/estado-se/sergipe/aracaju\`

      **Sua Missão**
      Analise os critérios abaixo e construa a URL Mestra seguindo rigorosamente a lógica e os exemplos. Sua resposta final deve ser **APENAS a URL completa**, como uma string de texto puro.

      **Critérios Fornecidos:**
      - Cidade/Estado: ${config.city}, ${config.state}
      - Palavra-chave: ${config.keyword || 'Nenhuma'}
      - Tipos de Imóvel: ${config.propertyTypes.join(', ')}
      - Subtipos de Imóvel: ${config.propertySubtypes.join(', ') || 'Nenhum'}
      - Comodidades: ${config.amenities.join(', ') || 'Nenhuma'}
      - Detalhes do Condomínio: ${config.condoAmenities.join(', ') || 'Nenhum'}
      - Tipo de Transação: ${config.transactionType}
      - Faixa de Preço: R$ ${config.minPrice > 0 ? config.minPrice : 'Qualquer'} a R$ ${config.maxPrice > 0 ? config.maxPrice : 'Qualquer'}
      - Faixa de Condomínio: R$ ${config.minCondoFee > 0 ? config.minCondoFee : 'Qualquer'} a R$ ${config.maxCondoFee > 0 ? config.maxCondoFee : 'Qualquer'}
      - Faixa de IPTU: R$ ${config.minIptu > 0 ? config.minIptu : 'Qualquer'} a R$ ${config.maxIptu > 0 ? config.maxIptu : 'Qualquer'}
      - Faixa de Área: ${config.minArea > 0 ? config.minArea : 'Qualquer'}m² a ${config.maxArea > 0 ? config.maxArea : 'Qualquer'}m²
      - Quartos (mín): ${config.bedrooms || 'Qualquer'}
      - Banheiros (mín): ${config.bathrooms || 'Qualquer'}
      - Vagas Garagem (mín): ${config.garageSpaces || 'Qualquer'}
      - Tipo de Anunciante: ${config.sellerType}
      - Ordenação: ${config.sort}

      Construa a URL agora.
  `;
  try {
      const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: prompt,
      });

      const responseText = response.text.trim();
      // Use a regex to find the first http/https link in the response,
      // making it robust against extra text or markdown from the AI.
      const urlMatch = responseText.match(/https?:\/\/[^\s`]+/);
      const url = urlMatch ? urlMatch[0] : '';

      if (!url.startsWith('http')) {
        console.error("Invalid URL format from Gemini:", responseText);
        throw new Error('A IA retornou uma URL em um formato inválido.');
      }
      return url;
  } catch (error) {
      console.error("Error generating URL from Gemini API:", error);
      throw new Error("Falha ao gerar a URL de busca. Verifique a chave da API e a conexão.");
  }
}
