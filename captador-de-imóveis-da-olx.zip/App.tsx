import React, { useState, useEffect } from 'react';
import { ScraperConfig, PropertyType, TransactionType, SortType, Amenity, PropertySubtype, SellerType } from './types';
import { ConfigMenu } from './components/ConfigMenu';
import { GeneratedLinkPanel } from './components/GeneratedLinkPanel';
import { generateOlxUrl, buildLocationSearchUrl } from './services/geminiService';

const DEFAULT_CONFIG: ScraperConfig = {
  city: 'Aracaju',
  state: 'SE',
  neighborhoods: [],
  municipalities: [],
  keyword: '',
  propertyTypes: [PropertyType.Casa],
  propertySubtypes: [],
  amenities: [Amenity.Piscina, Amenity.Varanda],
  condoAmenities: [],
  transactionType: TransactionType.Venda,
  minPrice: 0,
  maxPrice: 0,
  minCondoFee: 0,
  maxCondoFee: 0,
  minIptu: 0,
  maxIptu: 0,
  minArea: 0,
  maxArea: 0,
  bedrooms: 0,
  bathrooms: 0,
  garageSpaces: 0,
  sellerType: SellerType.Particular,
  sort: SortType.Relevantes,
  olxGuarantee: undefined,
  schedule: {
    enabled: false,
    time: "09:00",
  }
};

const App: React.FC = () => {
  const [config, setConfig] = useState<ScraperConfig>(() => {
    try {
      const savedConfig = localStorage.getItem('scraperConfig');
      if (savedConfig) {
        const parsed = JSON.parse(savedConfig);
        
        // Migration from old `onlyOwner` to new `sellerType`
        if (typeof parsed.onlyOwner !== 'undefined') {
          parsed.sellerType = parsed.onlyOwner ? SellerType.Particular : SellerType.Todos;
          delete parsed.onlyOwner;
        }

        // Ensure all keys from default are present
        return { ...DEFAULT_CONFIG, ...parsed, schedule: { ...DEFAULT_CONFIG.schedule, ...parsed.schedule } };
      }
    } catch (error) {
      console.error("Failed to parse saved config:", error);
    }
    return DEFAULT_CONFIG;
  });

  const [searchUrl, setSearchUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRun = async (urlOverride?: string) => {
    setIsLoading(true);
    setError(null);
    setSearchUrl(null);

    // Short delay to ensure loading UI shows up
    await new Promise(resolve => setTimeout(resolve, 50));

    if (urlOverride) {
      setSearchUrl(urlOverride);
      setIsLoading(false);
      return;
    }

    try {
      let url: string;
      const isLocationSearch = config.neighborhoods.length > 0 || config.municipalities.length > 0;

      if (isLocationSearch) {
        // This path is now mostly a fallback, as the live URL is passed directly.
        url = buildLocationSearchUrl(config);
      } else {
        // Use the existing Gemini service for general searches
        url = await generateOlxUrl(config);
      }
      
      setSearchUrl(url);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'Ocorreu um erro desconhecido.';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveConfig = () => {
    try {
      localStorage.setItem('scraperConfig', JSON.stringify(config));
      alert('Configurações salvas como padrão!');
    } catch (error) {
      console.error("Failed to save config:", error);
      alert('Falha ao salvar as configurações.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-slate-200">
      <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-10 shadow-md border-b border-slate-200 dark:border-slate-700">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
            Gerador de Links de Busca
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Configure os filtros e gere um link de busca avançada para a OLX.
          </p>
        </div>
      </header>
      
      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="w-full md:w-auto md:sticky md:top-24">
            <ConfigMenu
              config={config}
              setConfig={setConfig}
              onRun={handleRun}
              onSave={handleSaveConfig}
              isLoading={isLoading}
            />
          </div>

          <div className="flex-1 w-full min-w-0">
            <GeneratedLinkPanel
              isLoading={isLoading}
              searchUrl={searchUrl}
              error={error}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
