import { PastedAdData } from './types';

/**
 * Type guard robusto que valida a estrutura e a versão do schema de um anúncio colado.
 * Garante que apenas dados com schemaVersion >= 1 sejam processados.
 */
export function isPastedAdData(x: unknown): x is PastedAdData {
  if (!x || typeof x !== "object") return false;
  const o = x as any;
  return (
    typeof o.schemaVersion === "number" && o.schemaVersion >= 1 &&
    typeof o.title === "string" &&
    (o.price === null || typeof o.price === "number") &&
    typeof o.listingUrl === "string" &&
    typeof o.ownerBadge === "boolean" &&
    (o.listingId === undefined || o.listingId === null || typeof o.listingId === "string") &&
    (o.timestamp === undefined || typeof o.timestamp === "string")
  );
}

/**
 * Normaliza e valida com segurança a entrada de texto colado.
 * Filtra itens inválidos, avisa sobre dados parcialmente corretos e lança erros específicos.
 */
export function safeNormalize(input: unknown): PastedAdData[] {
  try {
    const parsed = Array.isArray(input) ? input : [input];
    
    const valid = parsed.filter(isPastedAdData);
    
    if (parsed.length > 0 && valid.length < parsed.length) {
        console.warn("Alguns itens do JSON colado foram ignorados por não corresponderem a um schema válido (versão >= 1).", {
            total: parsed.length,
            valid: valid.length,
            ignored: parsed.length - valid.length
        });
    }

    if (parsed.length > 0 && valid.length === 0) {
        throw new Error("Nenhum item válido no JSON. Verifique se o formato e a versão do schema (schemaVersion) estão corretos.");
    }

    return valid;
  } catch (e) {
    if (e instanceof Error && e.message.startsWith("Nenhum item válido")) {
        throw e;
    }
    throw new Error("JSON inválido. Cole exatamente o que o bookmarklet gerou.");
  }
}

export function coerceTimestamp(ad: PastedAdData): PastedAdData {
  return ad.timestamp ? ad : { ...ad, timestamp: new Date().toISOString() };
}

export function canonicalId(ad: PastedAdData): string {
  if (ad.listingId && /listing_\d+/.test(ad.listingId)) return ad.listingId;
  // fallback: hash estável de title+url
  const s = (ad.title + "|" + ad.listingUrl).toLowerCase();
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h += (h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24); }
  return "h_" + (h >>> 0).toString(16);
}

export function dedupeAppend(
  current: PastedAdData[],
  incoming: PastedAdData[],
): { added: PastedAdData[]; kept: PastedAdData[] } {
  const seen = new Set(current.map(canonicalId));
  const toAdd: PastedAdData[] = [];
  for (const ad of incoming.map(coerceTimestamp)) {
    const id = canonicalId(ad);
    if (!seen.has(id)) { seen.add(id); toAdd.push(ad); }
  }
  return { added: toAdd, kept: current };
}

export function pruneTTL(items: PastedAdData[], days = 7): PastedAdData[] {
  const now = Date.now();
  const ttl = days * 24 * 60 * 60 * 1000;
  return items.filter(it => {
    const t = it.timestamp ? Date.parse(it.timestamp) : NaN;
    return Number.isFinite(t) ? now - t <= ttl : true; // sem timestamp? mantém
  });
}

const KEY = "olx_capture_history_v1";
export function loadHistory(): PastedAdData[] {
  try { 
    const items = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(items) ? items.filter(isPastedAdData) : [];
  } catch { 
    return []; 
  }
}
export function saveHistory(items: PastedAdData[]): void {
  localStorage.setItem(KEY, JSON.stringify(items));
}

export function exportJSON(items: PastedAdData[]) {
  if (!items || items.length === 0) {
    alert("Não há dados no histórico para exportar.");
    return;
  }
  const blob = new Blob([JSON.stringify(items, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "olx-capturas.json";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
