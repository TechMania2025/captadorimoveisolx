
import React, { useState } from 'react';
import { Ad, TransactionType } from '../types';
import { AdCard } from './AdCard';
import { XCircleIcon, InfoIcon, CopyIcon, CheckIcon } from './shared/Icons';

type CaptureStep = 'idle' | 'generating' | 'awaitingPaste' | 'complete' | 'error';

interface ResultsPanelProps {
    logs: string[];
    captureStep: CaptureStep;
    newlyCapturedAds: Ad[];
    persistedAds: Ad[];
    searchUrl: string | null;
    transactionType: TransactionType;
    error: string | null;
    pasteFeedback: string | null;
    onPaste: (pastedText: string) => void;
    onClearHistory: () => void;
    onExport: () => void;
}

const bookmarkletTop3 = `javascript:(function(){function sleep(ms){return new Promise(r=>setTimeout(r,ms))}function cards(){try{return [...document.querySelectorAll('a[data-ds-component="DS-ProductCard"]')]}catch(e){return[]}}function isBoosted(el){return /impulsionado/i.test(el.innerText)}function isOwner(el){return /(direto\\s*com\\s*o\\s*propriet[aá]rio)/i.test(el.innerText)}function abs(h){return h&&h.startsWith('http')?h:\`https://www.olx.com.br\${h||''}\`}function num(txt){if(!txt)return null;const n=txt.replace(/[^\\d]/g,'');return n?Number(n):null}function lid(url){const m=String(url).match(/listing_\\d+/);return m?m[0]:null}async function wait(ms=7000){const t=Date.now();let c=cards();while(c.length===0 && Date.now()-t<ms){await sleep(300);c=cards()}return c}async function main(){try{let c=await wait();if(!c.length){alert('Nenhum anúncio encontrado.');return}window.scrollBy(0,1);await sleep(200);c=cards();const preferred=c.filter(x=>!isBoosted(x)&&isOwner(x));const fallback=c.filter(x=>!isBoosted(x)&&!preferred.includes(x));const pick=[...preferred,...fallback].slice(0,3);const out=pick.map(a=>{const href=a.getAttribute('href')||a.href;const url=abs(href);const root=a.closest('article')||a;const title=(root.querySelector('h2,h3')||a).innerText.trim();const priceTxt=(root.innerText.match(/R\\$\\s?[\\d\\.\\,]+/)||[''])[0]||null;return {schemaVersion:1,title,price:num(priceTxt),listingUrl:url,ownerBadge:isOwner(root),listingId:lid(url),timestamp:new Date().toISOString()};});const payload=JSON.stringify(out,null,2);if(navigator.clipboard&&navigator.clipboard.writeText){try{await navigator.clipboard.writeText(payload);alert('Até 3 anúncios copiados. Cole no app.');return}catch(e){}}window.open('data:application/json;charset=utf-8,'+encodeURIComponent(payload),'_blank')}catch(e){alert('Erro: '+(e&&e.message||e))}}main()})();`;

const ClipboardCopy: React.FC<{ textToCopy: string }> = ({ textToCopy }) => {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="relative">
            <pre className="bg-slate-900 text-white font-mono text-xs p-4 rounded-md overflow-x-auto">
                <code>{textToCopy}</code>
            </pre>
            <button
                onClick={handleCopy}
                className="absolute top-2 right-2 p-2 bg-slate-700 hover:bg-slate-600 rounded-md text-slate-300 transition-colors"
                aria-label="Copiar código"
            >
                {copied ? <CheckIcon /> : <CopyIcon />}
            </button>
        </div>
    );
};

const isMobile = /(Android|iPhone|iPad)/i.test(navigator.userAgent);

const AwaitingPaste: React.FC<{ searchUrl: string, onPaste: (text: string) => void }> = ({ searchUrl, onPaste }) => (
    <div className="bg-white dark:bg-slate-800/50 p-6 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 space-y-6">
        <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">
                <span className="text-2xl mr-2">1.</span> Abra a Página de Busca
            </h3>
            <p className="text-slate-600 dark:text-slate-400 ml-8 mb-3">
                Clique no link abaixo para abrir os resultados da busca da OLX em uma nova aba.
            </p>
            <a href={searchUrl} target="_blank" rel="noopener noreferrer" className="ml-8 inline-block bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 font-medium py-2 px-4 rounded-lg hover:bg-sky-200 dark:hover:bg-sky-800 transition-colors break-all">
                {searchUrl}
            </a>
        </div>

        <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">
                <span className="text-2xl mr-2">2.</span> Crie e Use o Bookmarklet
            </h3>
            <div className="text-slate-600 dark:text-slate-400 ml-8 mb-3 space-y-4">
                 <p>Para capturar os dados, você usará um "favorito mágico" (bookmarklet). Copie o código abaixo e siga as instruções para o seu dispositivo.</p>
                <ClipboardCopy textToCopy={bookmarkletTop3} />
                
                {isMobile ? (
                    <div className="text-sm p-4 bg-slate-100 dark:bg-slate-900/50 rounded-lg">
                        <h4 className="font-bold text-slate-700 dark:text-slate-200">Instruções para Celular:</h4>
                        <ol className="list-decimal list-inside mt-2 space-y-1">
                            <li>Adicione qualquer página aos seus favoritos.</li>
                            <li>Edite o favorito que você acabou de criar.</li>
                            <li>No campo do <span className="font-bold">endereço/URL</span>, apague o link existente e <span className="font-bold">cole o código</span> que você copiou. Salve.</li>
                            <li>Com a página de busca da OLX aberta, acesse seus favoritos e clique no que você acabou de criar.</li>
                        </ol>
                    </div>
                ) : (
                     <div className="text-sm p-4 bg-slate-100 dark:bg-slate-900/50 rounded-lg">
                        <h4 className="font-bold text-slate-700 dark:text-slate-200">Instruções para Desktop:</h4>
                         <ol className="list-decimal list-inside mt-2 space-y-1">
                             <li>Clique com o botão direito na sua barra de favoritos e selecione "Adicionar página".</li>
                             <li>Dê um nome (ex: "Capturar OLX").</li>
                             <li>No campo <span className="font-bold">URL</span>, <span className="font-bold">cole o código</span> que você copiou. Salve.</li>
                             <li>Com a página de busca da OLX aberta, clique no favorito que você criou.</li>
                         </ol>
                    </div>
                )}
            </div>
        </div>

        <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">
                <span className="text-2xl mr-2">3.</span> Cole o Resultado Aqui
            </h3>
            <div className="text-slate-600 dark:text-slate-400 ml-8 mb-3 space-y-3">
                 <p>
                    Após usar o bookmarklet na página da OLX, os dados de até 3 anúncios serão copiados. Cole o resultado abaixo.
                </p>
                 <div className="text-sm p-3 bg-sky-50 dark:bg-sky-900/40 rounded-lg border border-sky-200 dark:border-sky-800/50">
                    <InfoIcon />
                    <span className="ml-2">Se uma nova aba abrir com o texto, a cópia automática falhou. Apenas copie todo o texto da nova aba e cole aqui.</span>
                </div>
                <textarea
                    className="w-full h-32 p-3 font-mono text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Cole o JSON dos anúncios aqui..."
                    onChange={(e) => onPaste(e.target.value)}
                    aria-label="Área para colar os dados do anúncio"
                />
            </div>
        </div>
    </div>
);


const PasteResults: React.FC<Omit<ResultsPanelProps, 'captureStep' | 'searchUrl' | 'error' | 'logs' | 'onPaste'>> = ({ newlyCapturedAds, persistedAds, transactionType, pasteFeedback, onClearHistory, onExport }) => {
    return (
        <div className="space-y-6">
            {pasteFeedback && (
                <div aria-live="polite" className="p-4 text-center rounded-lg bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800/50 text-green-800 dark:text-green-200">
                    <p className="font-semibold">{pasteFeedback}</p>
                </div>
            )}

            {newlyCapturedAds.length > 0 && (
                <section>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Recém Capturados</h3>
                    <div className="space-y-4">
                        {newlyCapturedAds.map(ad => <AdCard key={ad.link} ad={ad} transactionType={transactionType} />)}
                    </div>
                </section>
            )}

            <section>
                <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                    <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">
                        Histórico ({persistedAds.length} salvo{persistedAds.length !== 1 && 's'})
                    </h3>
                    {persistedAds.length > 0 && (
                        <div className="flex gap-2">
                             <button onClick={onExport} className="px-3 py-1.5 text-sm font-semibold text-sky-700 dark:text-sky-300 bg-sky-100 dark:bg-sky-900/50 rounded-md hover:bg-sky-200 dark:hover:bg-sky-800">Exportar JSON</button>
                             <button onClick={onClearHistory} className="px-3 py-1.5 text-sm font-semibold text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900/50 rounded-md hover:bg-red-200 dark:hover:bg-red-800">Limpar Histórico</button>
                        </div>
                    )}
                </div>
                {persistedAds.length > 0 ? (
                    <div className="space-y-4">
                        {persistedAds.map(ad => <AdCard key={ad.link} ad={ad} transactionType={transactionType} />)}
                    </div>
                ) : (
                    <div className="text-center p-8 bg-white dark:bg-slate-800/50 rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-700">
                        <p className="text-slate-500 dark:text-slate-400">Seu histórico de anúncios capturados está vazio.</p>
                        <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">Use a função de captura para começar a salvar anúncios.</p>
                    </div>
                )}
            </section>
        </div>
    );
};


export const ResultsPanel: React.FC<ResultsPanelProps> = (props) => {
    const { captureStep, searchUrl, error, onPaste } = props;
    
    if (captureStep === 'generating') {
         return (
            <div className="bg-white dark:bg-slate-800/50 p-6 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center">
                <svg className="animate-spin h-8 w-8 text-sky-600 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">Gerando URL...</h3>
                <p className="text-slate-500 dark:text-slate-400 mt-1">A IA está construindo o link de busca da OLX com base nos seus filtros.</p>
            </div>
        );
    }
    
    return (
        <div className="flex-1 space-y-6">
            {captureStep === 'awaitingPaste' && searchUrl && <AwaitingPaste searchUrl={searchUrl} onPaste={onPaste} />}

            {captureStep === 'complete' && <PasteResults {...props} />}
            
            {captureStep === 'error' && error && (
                 <div className="bg-red-50 dark:bg-red-900/30 p-6 rounded-xl shadow-lg border border-red-200 dark:border-red-800/50 text-center">
                    <XCircleIcon />
                    <h3 className="text-xl font-bold text-red-800 dark:text-red-200 mt-3">Ocorreu um Erro</h3>
                    <p className="text-red-700 dark:text-red-300 mt-2">{error}</p>
                </div>
            )}
        </div>
    );
};
