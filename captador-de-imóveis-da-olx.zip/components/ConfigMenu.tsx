import React, { useState, KeyboardEvent, useEffect } from 'react';
import { ScraperConfig, PropertyType, TransactionType, SortType, Amenity, PropertySubtype, SellerType, CondoAmenity } from '../types';
import { SettingsIcon, PlayIcon, XIcon, SaveIcon } from './shared/Icons';
import { buildLocationSearchUrl } from '../services/geminiService';

interface ConfigMenuProps {
  config: ScraperConfig;
  setConfig: React.Dispatch<React.SetStateAction<ScraperConfig>>;
  onRun: (urlOverride?: string) => void;
  onSave: () => void;
  isLoading: boolean;
}

const Section: React.FC<{ title: string; children: React.ReactNode; }> = ({ title, children }) => (
    <div>
        <h3 className="text-base font-semibold text-slate-800 dark:text-slate-200 mb-3">{title}</h3>
        <div className="space-y-4">{children}</div>
    </div>
);

const Label: React.FC<{ htmlFor?: string; children: React.ReactNode }> = ({ htmlFor, children }) => (
  <label htmlFor={htmlFor} className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">{children}</label>
);

const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <input {...props} className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500 text-slate-900 dark:text-slate-100 disabled:bg-slate-100 dark:disabled:bg-slate-700" />
);

const Toggle: React.FC<{ checked: boolean; onChange: (checked: boolean) => void; label: string; rightContent?: React.ReactNode }> = ({ checked, onChange, label, rightContent }) => (
  <div className="flex items-center justify-between">
    <span className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center">{label}{rightContent}</span>
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`${checked ? 'bg-violet-600' : 'bg-slate-300 dark:bg-slate-600'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500`}
    >
      <span className={`${checked ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`} />
    </button>
  </div>
);

const RangeInputGroup: React.FC<{
  label: string;
  minVal: number;
  maxVal: number;
  onMinChange: (val: number) => void;
  onMaxChange: (val: number) => void;
}> = ({ label, minVal, maxVal, onMinChange, onMaxChange }) => (
    <div>
        <Label>{label}</Label>
        <div className="grid grid-cols-2 gap-2">
            <Input type="number" value={minVal || ''} onChange={e => onMinChange(Number(e.target.value))} placeholder="Mín." aria-label={`${label} mínimo`} />
            <Input type="number" value={maxVal || ''} onChange={e => onMaxChange(Number(e.target.value))} placeholder="Máx." aria-label={`${label} máximo`} 
              className={maxVal > 0 ? 'border-violet-500 ring-2 ring-violet-500' : ''}
            />
        </div>
    </div>
);

const NumericButtonGroup: React.FC<{
  label: string;
  value: number;
  onChange: (value: number) => void;
}> = ({ label, value, onChange }) => {
    const options = ['0', '1', '2', '3', '4', '5+'];
    return (
        <div>
            <Label>{label}</Label>
            <div className="flex flex-wrap gap-2 mt-1">
                {options.map(opt => {
                    const optValue = parseInt(String(opt).replace('+', ''));
                    const isActive = value === optValue;
                    return (
                        <button
                            key={opt}
                            type="button"
                            onClick={() => onChange(isActive ? 0 : optValue)}
                            className={`px-4 py-2 text-sm font-medium border rounded-md transition-colors w-12 text-center ${
                                isActive
                                ? 'bg-violet-600 border-violet-600 text-white'
                                : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                            }`}
                        >
                            {opt}
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

export const ConfigMenu: React.FC<ConfigMenuProps> = ({ config, setConfig, onRun, onSave, isLoading }) => {
  const [neighborhoodInput, setNeighborhoodInput] = useState('');
  const [municipalityInput, setMunicipalityInput] = useState('');
  const [liveUrl, setLiveUrl] = useState('');
  
  const isLocationSpecificSearch = config.neighborhoods.length > 0 || config.municipalities.length > 0;
  const isTypingLocation = neighborhoodInput.trim() !== '' || municipalityInput.trim() !== '';
  const isLocationSearchActive = isLocationSpecificSearch || isTypingLocation;

  useEffect(() => {
    if (isLocationSearchActive) {
      // Create a temporary config that includes the text being typed for a live preview
      const tempConfig = { ...config };
      const neighborhoodQuery = neighborhoodInput.trim();
      const municipalityQuery = municipalityInput.trim();

      if (neighborhoodQuery) {
        tempConfig.neighborhoods = [...config.neighborhoods, neighborhoodQuery];
        tempConfig.municipalities = []; // Mutually exclusive
      } else if (municipalityQuery) {
        tempConfig.municipalities = [...config.municipalities, municipalityQuery];
        tempConfig.neighborhoods = []; // Mutually exclusive
      }

      try {
        const url = buildLocationSearchUrl(tempConfig);
        setLiveUrl(url);
      } catch (e) {
        setLiveUrl('Erro ao gerar URL. Verifique o estado.');
      }
    } else {
      setLiveUrl('');
    }
  }, [config, neighborhoodInput, municipalityInput, isLocationSearchActive]);


  const handlePropertyTypeChange = (type: PropertyType) => {
    const newTypes = config.propertyTypes.includes(type)
      ? config.propertyTypes.filter(t => t !== type)
      : [...config.propertyTypes, type];
    setConfig(prev => ({ ...prev, propertyTypes: newTypes }));
  };

  const handlePropertySubtypeChange = (subtype: PropertySubtype) => {
    const newSubtypes = config.propertySubtypes.includes(subtype)
      ? config.propertySubtypes.filter(s => s !== subtype)
      : [...config.propertySubtypes, subtype];
    setConfig(prev => ({...prev, propertySubtypes: newSubtypes}));
  };
  
  const handleAmenityChange = (amenity: Amenity) => {
    const newAmenities = config.amenities.includes(amenity)
      ? config.amenities.filter(a => a !== amenity)
      : [...config.amenities, amenity];
    setConfig(prev => ({...prev, amenities: newAmenities}));
  };

  const handleCondoAmenityChange = (amenity: CondoAmenity) => {
    const newCondoAmenities = config.condoAmenities.includes(amenity)
      ? config.condoAmenities.filter(a => a !== amenity)
      : [...config.condoAmenities, amenity];
    setConfig(prev => ({...prev, condoAmenities: newCondoAmenities}));
  };

  const resetAdvancedFilters = (newConfig: ScraperConfig): ScraperConfig => {
      newConfig.propertyTypes = [];
      newConfig.propertySubtypes = [];
      newConfig.amenities = [];
      newConfig.condoAmenities = [];
      newConfig.minCondoFee = 0;
      newConfig.maxCondoFee = 0;
      newConfig.minIptu = 0;
      newConfig.maxIptu = 0;
      newConfig.minArea = 0;
      newConfig.maxArea = 0;
      newConfig.bedrooms = 0;
      newConfig.bathrooms = 0;
      newConfig.garageSpaces = 0;
      return newConfig;
  }

  const handleAddNeighborhood = () => {
    if (neighborhoodInput && !config.neighborhoods.includes(neighborhoodInput)) {
        const isFirstLocationFilter = config.neighborhoods.length === 0 && config.municipalities.length === 0;
        setConfig(prev => {
            let newConfig: ScraperConfig = { 
                ...prev, 
                municipalities: [], // Clear municipalities when adding a neighborhood
                neighborhoods: [...prev.neighborhoods, neighborhoodInput.trim()] 
            };
            if (isFirstLocationFilter) {
                newConfig = resetAdvancedFilters(newConfig);
            }
            return newConfig;
        });
        setNeighborhoodInput('');
    }
  };

  const handleNeighborhoodKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddNeighborhood();
    }
  };
  
  const handleRemoveNeighborhood = (neighborhood: string) => {
    setConfig(prev => ({ ...prev, neighborhoods: prev.neighborhoods.filter(n => n !== neighborhood) }));
  };

  const handleAddMunicipality = () => {
    if (municipalityInput && !config.municipalities.includes(municipalityInput)) {
        const isFirstLocationFilter = config.neighborhoods.length === 0 && config.municipalities.length === 0;
        setConfig(prev => {
            let newConfig: ScraperConfig = { 
                ...prev, 
                neighborhoods: [], // Clear neighborhoods when adding a municipality
                municipalities: [...prev.municipalities, municipalityInput.trim()] 
            };
            if (isFirstLocationFilter) {
                newConfig = resetAdvancedFilters(newConfig);
            }
            return newConfig;
        });
        setMunicipalityInput('');
    }
  };

  const handleMunicipalityKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddMunicipality();
    }
  };

  const handleRemoveMunicipality = (municipality: string) => {
    setConfig(prev => ({ ...prev, municipalities: prev.municipalities.filter(m => m !== municipality) }));
  };

  const handleOlxGuaranteeChange = (value: 1 | 2) => {
    setConfig(prev => ({
      ...prev,
      olxGuarantee: prev.olxGuarantee === value ? undefined : value,
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocationSearchActive) {
      onRun(liveUrl);
    } else {
      onRun();
    }
  };

  return (
    <div className="w-full md:w-96 bg-white dark:bg-slate-800/50 p-6 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 h-full overflow-y-auto">
      <div className="flex items-center mb-6">
        <SettingsIcon />
        <h2 className="text-2xl font-bold ml-3 text-slate-900 dark:text-slate-100">Configurações</h2>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="space-y-8">
          
          {!isLocationSearchActive && (
            <>
              <Section title="Tipo do imóvel">
                 <div className="space-y-3">
                  {Object.values(PropertyType).map(type => (
                    <div key={type} className="flex items-center">
                      <input id={type} name="property-type" type="checkbox" checked={config.propertyTypes.includes(type)} onChange={() => handlePropertyTypeChange(type)} 
                       className="h-5 w-5 rounded-md border-gray-300 text-violet-600 focus:ring-violet-500" 
                      />
                      <label htmlFor={type} className="ml-3 block text-base text-gray-900 dark:text-gray-300">
                        {type} {config.transactionType === TransactionType.Venda ? 'à venda' : 'para aluguel'}
                      </label>
                    </div>
                  ))}
                </div>
              </Section>

              <Section title="Subtipo do imóvel">
                <div className="flex flex-wrap gap-2">
                  {Object.values(PropertySubtype).map(subtype => (
                      <button
                          key={subtype}
                          type="button"
                          onClick={() => handlePropertySubtypeChange(subtype)}
                          className={`px-4 py-2 text-sm font-medium border rounded-full transition-colors ${
                              config.propertySubtypes.includes(subtype)
                                  ? 'bg-violet-600 border-violet-600 text-white'
                                  : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                          }`}
                      >
                          {subtype}
                      </button>
                  ))}
                </div>
              </Section>
            </>
          )}

          <div className="space-y-4">
             <RangeInputGroup label="Preço" minVal={config.minPrice} maxVal={config.maxPrice} onMinChange={v => setConfig(p => ({...p, minPrice: v}))} onMaxChange={v => setConfig(p => ({...p, maxPrice: v}))} />
             {!isLocationSearchActive && (
                <>
                    <RangeInputGroup label="Condomínio" minVal={config.minCondoFee} maxVal={config.maxCondoFee} onMinChange={v => setConfig(p => ({...p, minCondoFee: v}))} onMaxChange={v => setConfig(p => ({...p, maxCondoFee: v}))} />
                    <RangeInputGroup label="IPTU" minVal={config.minIptu} maxVal={config.maxIptu} onMinChange={v => setConfig(p => ({...p, minIptu: v}))} onMaxChange={v => setConfig(p => ({...p, maxIptu: v}))} />
                </>
             )}
          </div>

          {!isLocationSearchActive && (
            <>
              <div className="space-y-4">
                  <NumericButtonGroup label="Número de quartos" value={config.bedrooms} onChange={v => setConfig(p => ({...p, bedrooms: v}))} />
                  <NumericButtonGroup label="Número de banheiros" value={config.bathrooms} onChange={v => setConfig(p => ({...p, bathrooms: v}))} />
                  <NumericButtonGroup label="Vagas na garagem" value={config.garageSpaces} onChange={v => setConfig(p => ({...p, garageSpaces: v}))} />
              </div>
              
              <div className="space-y-4">
                  <RangeInputGroup label="Área" minVal={config.minArea} maxVal={config.maxArea} onMinChange={v => setConfig(p => ({...p, minArea: v}))} onMaxChange={v => setConfig(p => ({...p, maxArea: v}))} />
              </div>

              <Section title="Detalhes do imóvel">
                  <div className="columns-2 gap-x-6 space-y-3">
                  {Object.values(Amenity).map(amenity => (
                      <div key={amenity} className="flex items-center break-inside-avoid">
                      <input id={amenity} name="amenity" type="checkbox" checked={config.amenities.includes(amenity)} onChange={() => handleAmenityChange(amenity)} className="h-4 w-4 rounded border-gray-300 text-violet-600 focus:ring-violet-500" />
                      <label htmlFor={amenity} className="ml-2 block text-sm text-gray-900 dark:text-gray-300">{amenity}</label>
                      </div>
                  ))}
                  </div>
              </Section>

              <Section title="Detalhes do condomínio">
                  <div className="columns-2 gap-x-6 space-y-3">
                  {Object.values(CondoAmenity).map(amenity => (
                      <div key={`condo-${amenity}`} className="flex items-center break-inside-avoid">
                      <input id={`condo-${amenity}`} name="condo-amenity" type="checkbox" checked={config.condoAmenities.includes(amenity)} onChange={() => handleCondoAmenityChange(amenity)} className="h-4 w-4 rounded border-gray-300 text-violet-600 focus:ring-violet-500" />
                      <label htmlFor={`condo-${amenity}`} className="ml-2 block text-sm text-gray-900 dark:text-gray-300">{amenity}</label>
                      </div>
                  ))}
                  </div>
              </Section>
              <hr className="border-slate-200 dark:border-slate-700" />
            </>
          )}

          <Section title="Localização e outros filtros">
            <div className="space-y-4">
              {!isLocationSpecificSearch && (
                <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="city">Cidade</Label>
                      <Input id="city" type="text" value={config.city} onChange={(e) => setConfig(p => ({ ...p, city: e.target.value }))} />
                    </div>
                    <div>
                      <Label htmlFor="state">Estado</Label>
                      <Input id="state" type="text" value={config.state} onChange={(e) => setConfig(p => ({ ...p, state: e.target.value }))} />
                    </div>
                </div>
              )}
              
              {/* Show Neighborhoods input if no municipalities are selected or being typed */}
              {(config.municipalities.length === 0 && municipalityInput.trim() === '') && (
                <div>
                  <Label htmlFor="neighborhoods">Bairros (Opcional)</Label>
                  <datalist id="aracaju-neighborhoods">
                    <option value="Aruana" /><option value="Atalaia" /><option value="Coroa do Meio" /><option value="Farolândia" /><option value="Jardins" /><option value="Luzia" /><option value="Ponto Novo" /><option value="Salgado Filho" /><option value="Grageru" /><option value="13 de Julho" /><option value="Suíssa" /><option value="Santos Dumont" /><option value="Itabaiana" />
                  </datalist>
                  <div className="flex">
                    <Input id="neighborhoods" type="text" value={neighborhoodInput} onChange={(e) => setNeighborhoodInput(e.target.value)} onKeyDown={handleNeighborhoodKeyDown} placeholder="Adicionar bairro e pressionar Enter" list="aracaju-neighborhoods" />
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {config.neighborhoods.map(n => (
                      <span key={n} className="flex items-center bg-violet-100 dark:bg-violet-900 text-violet-800 dark:text-violet-200 text-xs font-medium px-2.5 py-1 rounded-full">
                        {n}
                        <button type="button" onClick={() => handleRemoveNeighborhood(n)} className="ml-1.5 -mr-1 p-0.5 rounded-full hover:bg-violet-200 dark:hover:bg-violet-700">
                          <XIcon />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Show Municipalities input if no neighborhoods are selected or being typed */}
              {(config.neighborhoods.length === 0 && neighborhoodInput.trim() === '') && (
                <div>
                  <Label htmlFor="municipalities">Municípios (Opcional)</Label>
                  <datalist id="aracaju-municipalities">
                      <option value="Nossa Senhora do Socorro" />
                      <option value="São Cristóvão" />
                      <option value="Barra dos Coqueiros" />
                      <option value="Itaporanga d'Ajuda" />
                  </datalist>
                  <div className="flex">
                    <Input id="municipalities" type="text" value={municipalityInput} onChange={(e) => setMunicipalityInput(e.target.value)} onKeyDown={handleMunicipalityKeyDown} placeholder="Adicionar município e pressionar Enter" list="aracaju-municipalities" />
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {config.municipalities.map(m => (
                      <span key={m} className="flex items-center bg-violet-100 dark:bg-violet-900 text-violet-800 dark:text-violet-200 text-xs font-medium px-2.5 py-1 rounded-full">
                        {m}
                        <button type="button" onClick={() => handleRemoveMunicipality(m)} className="ml-1.5 -mr-1 p-0.5 rounded-full hover:bg-violet-200 dark:hover:bg-violet-700">
                          <XIcon />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {isLocationSearchActive && (
                <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                  <Label>Opções da OLX</Label>
                  <div className="grid grid-cols-1 gap-2 mt-1">
                    <button
                      key="opst1"
                      type="button"
                      onClick={() => handleOlxGuaranteeChange(1)}
                      className={`w-full text-center px-3 py-2 text-sm font-medium border rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500 dark:focus:ring-offset-slate-800 ${
                        config.olxGuarantee === 1
                          ? 'bg-violet-600 border-violet-600 text-white'
                          : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      Anúncios com Garantia da OLX
                    </button>
                    <button
                      key="opst2"
                      type="button"
                      onClick={() => handleOlxGuaranteeChange(2)}
                      className={`w-full text-center px-3 py-2 text-sm font-medium border rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500 dark:focus:ring-offset-slate-800 ${
                        config.olxGuarantee === 2
                          ? 'bg-violet-600 border-violet-600 text-white'
                          : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      Garantia + Entrega
                    </button>
                  </div>
                </div>
              )}

              <div>
                <Label>Tipo de anunciante</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {Object.values(SellerType).map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setConfig(p => ({ ...p, sellerType: type }))}
                      className={`w-full text-center px-3 py-2 text-sm font-medium border rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500 dark:focus:ring-offset-slate-800 ${
                        config.sellerType === type
                          ? 'bg-violet-600 border-violet-600 text-white'
                          : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <Label>Ordenar por</Label>
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {Object.values(SortType).map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setConfig(p => ({ ...p, sort: type }))}
                      className={`w-full text-center px-3 py-2 text-sm font-medium border rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500 dark:focus:ring-offset-slate-800 ${
                        config.sort === type
                          ? 'bg-violet-600 border-violet-600 text-white'
                          : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </Section>

        </div>
        
        {isLocationSearchActive && (
          <div className="mt-6 space-y-2">
            <Label>URL em tempo real</Label>
            <div className="p-3 bg-slate-100 dark:bg-slate-900/50 rounded-md font-mono text-xs text-slate-500 dark:text-slate-400 break-all select-all">
              {liveUrl || 'https://www.olx.com.br/'}
            </div>
          </div>
        )}

        <div className="mt-8 flex flex-col gap-3">
          <button type="submit" disabled={isLoading} className="w-full flex items-center justify-center bg-violet-600 hover:bg-violet-700 text-white font-bold py-3 px-4 rounded-lg shadow-md transition-all duration-300 disabled:bg-slate-400 disabled:cursor-not-allowed">
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="http://www.w3.org/2000/svg">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Gerando URL...
              </>
            ) : (
              <>
                <PlayIcon />
                {isLocationSearchActive ? 'Mostrar Link de Busca' : 'Gerar Link de Busca'}
              </>
            )}
          </button>
          <button type="button" onClick={onSave} className="w-full flex items-center justify-center bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold py-2 px-4 rounded-lg transition-colors">
            <SaveIcon />
            Salvar como padrão
          </button>
        </div>
      </form>
    </div>
  );
};