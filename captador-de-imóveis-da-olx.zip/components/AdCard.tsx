
import React from 'react';
import { Ad, TransactionType } from '../types';
import { CalendarIcon, MapPinIcon, BedIcon, BathIcon, CarIcon, RulerIcon, InfoIcon } from './shared/Icons';

const DetailItem: React.FC<{ icon: React.ReactNode; value: string | number; label: string; }> = ({ icon, value, label }) => (
    <div className="flex items-center text-sm text-slate-600 dark:text-slate-300">
        <div className="flex-shrink-0">{icon}</div>
        <div className="ml-2">
            <span className="font-bold">{value}</span>
            <span className="ml-1 text-slate-500 dark:text-slate-400">{label}</span>
        </div>
    </div>
);


export const AdCard: React.FC<{ ad: Ad; transactionType: TransactionType; onVisit?: () => void; }> = ({ ad, transactionType, onVisit }) => {
  const isValidDate = ad.publishedAt && !isNaN(new Date(ad.publishedAt).getTime());
  const formattedDate = isValidDate
    ? new Date(ad.publishedAt as string).toLocaleString('pt-BR', {
        day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
      })
    : 'Data não informada';
    
  const hasPrice = typeof ad.preco_num === 'number';
  const isOwner = ad.sellerType === 'proprietario';

  return (
    <article className={`bg-white dark:bg-slate-800/50 rounded-xl shadow-lg border overflow-hidden transform hover:-translate-y-1 transition-all duration-300 ${isOwner ? 'border-slate-200 dark:border-slate-700' : 'border-amber-400 dark:border-amber-600'}`}>
      <div className="md:flex">
        {/* Media */}
        <div className="md:w-1/3 bg-slate-50 dark:bg-slate-800 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700">
          {ad.thumbnail ? (
            <img src={ad.thumbnail} alt={`Imagem de ${ad.titulo}`} className="h-full w-full object-cover"/>
          ) : (
            <div className="h-full w-full flex flex-col items-center justify-center p-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-slate-300 dark:text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Sem imagem</p>
            </div>
          )}
        </div>

        {/* Ad Content */}
        <div className="md:w-2/3 p-6 flex flex-col">
          <header className="relative">
            <div className="flex items-start justify-between gap-2">
                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-sky-600 bg-sky-200 dark:bg-sky-900 dark:text-sky-300">
                {ad.tipo || 'Imóvel'}
                </span>
                {isOwner ? (
                    <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-emerald-600 bg-emerald-100 dark:bg-emerald-900 dark:text-emerald-200">
                        Direto com Proprietário
                    </span>
                ) : (
                    <span className="text-xs font-semibold inline-flex items-center py-1 px-2 uppercase rounded-full text-amber-800 bg-amber-100 dark:bg-amber-900 dark:text-amber-200">
                        Sem Selo de Proprietário
                    </span>
                )}
            </div>
            
            <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mt-2">{ad.titulo || 'Título não informado'}</h3>
            <p className="text-3xl font-extrabold text-green-600 dark:text-green-400 mt-1">
              {hasPrice
                ? `R$ ${ad.preco_num.toLocaleString('pt-BR')}`
                : 'Preço a consultar'
              }
              {transactionType === TransactionType.Aluguel && hasPrice && <span className="text-lg font-medium text-slate-500 dark:text-slate-400"> /mês</span>}
            </p>
          </header>
            
          <section className="mt-4 grid grid-cols-2 lg:grid-cols-4 gap-y-4 gap-x-2 border-t border-b border-slate-200 dark:border-slate-700 py-4">
            {ad.bedrooms && <DetailItem icon={<BedIcon/>} value={ad.bedrooms} label="quarto(s)"/>}
            {ad.bathrooms && <DetailItem icon={<BathIcon/>} value={ad.bathrooms} label="banheiro(s)"/>}
            {ad.garages && <DetailItem icon={<CarIcon/>} value={ad.garages} label="vaga(s)"/>}
            {ad.area_m2 && <DetailItem icon={<RulerIcon/>} value={`${ad.area_m2} m²`} label="área"/>}
          </section>


          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-slate-600 dark:text-slate-400 py-4">
            <div className="flex items-center">
              <MapPinIcon />
              <div className="ml-2">
                <span className="font-semibold text-slate-700 dark:text-slate-300 block">Localização</span>
                <span>{ad.bairro || 'Bairro não inf.'}, {ad.cidade || 'Cidade não inf.'}</span>
              </div>
            </div>
            <div className="flex items-center">
              <CalendarIcon />
              <div className="ml-2">
                <span className="font-semibold text-slate-700 dark:text-slate-300 block">Capturado em</span>
                <span>{formattedDate}</span>
              </div>
            </div>
          </div>
          
          <footer className="mt-auto pt-6 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-end gap-4">
            <a 
              href={ad.link} 
              target="_blank" 
              rel="noopener noreferrer" 
              onClick={onVisit}
              className="w-full sm:w-auto inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-sky-600 hover:bg-sky-700 transition-colors"
            >
              Ver anúncio na OLX
            </a>
          </footer>
        </div>
      </div>
    </article>
  );
};
