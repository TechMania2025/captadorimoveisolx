

export enum TransactionType {
  Venda = "Venda",
  Aluguel = "Aluguel",
}

export enum PropertyType {
  Apartamento = "Apartamentos",
  Casa = "Casas",
}

export enum PropertySubtype {
  CasaDeCondominio = "Casa de condomínio",
  CasaDeVila = "Casa de vila",
  Cobertura = "Cobertura",
  DuplexOuTriplex = "Duplex ou triplex",
  Kitnet = "Kitnet",
  Loft = "Loft",
  Padrao = "Padrão",
  Flat = "Flat",
}

export enum SortType {
  Relevantes = "Mais Relevantes",
  Recentes = "Mais Recentes",
  MenorPreco = "Menor Preço",
  MaiorPreco = "Maior Preço",
}

export enum Amenity {
  Academia = "Academia",
  Aquecimento = "Aquecimento",
  ArCondicionado = "Ar condicionado",
  AreaDeServico = "Área de serviço",
  ArmariosNaCozinha = "Armários na cozinha",
  ArmariosNoQuarto = "Armários no quarto",
  BanheiroNoQuarto = "Banheiro no quarto",
  Churrasqueira = "Churrasqueira",
  Internet = "Internet",
  Mobiliado = "Mobiliado",
  Piscina = "Piscina",
  Porteiro24h = "Porteiro 24h",
  QuartoDeServico = "Quarto de serviço",
  SalaoDeFestas = "Salão de festas",
  TvACabo = "Tv a cabo",
  Varanda = "Varanda",
}

export enum CondoAmenity {
  CondoAcademia = "Academia",
  AreaMurada = "Área murada",
  CondominioFechado = "Condomínio fechado",
  Elevador = "Elevador",
  PermitidoAnimais = "Permitido animais",
  CondoPiscina = "Piscina",
  PortaoEletronico = "Portão eletrônico",
  Portaria = "Portaria",
  CondoSalaoDeFestas = "Salão de festas",
  Seguranca24h = "Segurança 24h",
}


export enum SellerType {
  Todos = "Todos",
  Particular = "Particular",
  Profissional = "Profissional",
}


export interface ScraperConfig {
  city: string;
  state: string;
  neighborhoods: string[];
  municipalities: string[];
  keyword: string;
  propertyTypes: PropertyType[];
  propertySubtypes: PropertySubtype[];
  amenities: Amenity[];
  condoAmenities: CondoAmenity[];
  transactionType: TransactionType;
  minPrice: number;
  maxPrice: number;
  minCondoFee: number;
  maxCondoFee: number;
  minIptu: number;
  maxIptu: number;
  minArea: number;
  maxArea: number;
  bedrooms: number;
  bathrooms: number;
  garageSpaces: number;
  sellerType: SellerType;
  sort: SortType;
  olxGuarantee?: 1 | 2;
  schedule: {
    enabled: boolean;
    time: string; // e.g., "09:00"
  };
}

// FIX: Add PastedAdData interface to define the structure of data pasted from the clipboard.
export interface PastedAdData {
  schemaVersion: number;
  title: string;
  price: number | null;
  listingUrl: string;
  ownerBadge: boolean;
  listingId?: string | null;
  timestamp?: string;
}

// FIX: Add Ad interface to define the structure for a processed ad object used in components.
export interface Ad {
  link: string;
  titulo: string;
  thumbnail?: string;
  publishedAt?: string;
  preco_num?: number;
  sellerType: string;
  tipo?: string;
  bedrooms?: number;
  bathrooms?: number;
  garages?: number;
  area_m2?: number;
  bairro?: string;
  cidade?: string;
}